<?php 
	session_start();

	$_SESSION["nama"] = "Ahmad Solichin";
	echo "<a href='session02.php'>Menuju ke halaman kedua</a>";
?>