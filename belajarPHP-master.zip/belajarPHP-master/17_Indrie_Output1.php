<?php
	$nama = [["Nama"=>"Satria", 
	"Kelas"=>"RPL 1"],
	["Nama"=>"Arsyi", 
	"Kelas"=>"RPL 2"],
	["Nama"=>"Dhika", 
	"Kelas"=>"RPL 3"],
	["Nama"=>"Evan", 
	"Kelas"=>"RPL 4"],
	["Nama"=>"Fabian", 
	"Kelas"=>"RPL 5"],
	["Nama"=>"Irfan", 
	"Kelas"=>"RPL 6"]];
	echo "<pre>";
	print_r($nama);
	echo "</pre>";
?>