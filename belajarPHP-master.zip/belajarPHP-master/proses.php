<!DOCTYPE html>
<html>
<head>
	<title>Proses</title>
</head>
<body>
	<h1>Halo, <?= $_POST["nama"];?><br>
		Alamatmu ada di  <?= $_POST["alamat"];  ?></h1>
</body>
</html>