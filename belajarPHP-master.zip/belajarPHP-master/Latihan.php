<!DOCTYPE html>
<html>
<head>
	<title>Get</title>
</head>
<body>
	<fieldset>
		<label>Input Data</label>
		<form method="GET" action="prosesData.php">
			<p>Nama : <input type="text" name="nama"></p>
			<p>Email : <input type="email" name="email"></p>
			<p><input type="submit" value="Proses Data" name="submit"></p>
		</form>
	</fieldset>
</body>
</html>